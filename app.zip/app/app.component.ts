import { Component,OnInit} from '@angular/core';
import { Observable, Subject,observable } from 'rxjs';
import { WebcamImage,WebcamInitError,WebcamUtil } from 'ngx-webcam/public_api';
import { __values } from 'tslib';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  private trigger:Subject<any> = new Subject();
  private webcamImage! : WebcamImage;
  private nextwebcam:Subject<any> = new Subject();
  captureImage = '';
  ngOnInit() {};
  public triggerSnapshot(): void {
   this.trigger.next(__values)
}
public handleImage(webcamImage: WebcamImage): void {
  this.webcamImage = webcamImage;
  this.captureImage = webcamImage!.imageAsDataUrl;
  console.info('received webcam image', this.captureImage);
}
public get triggerObservable(): Observable<any> {

  return this.trigger.asObservable();
}
public get nextWebcamObservable(): Observable<any> {

  return this.nextwebcam.asObservable();
}


  
}
